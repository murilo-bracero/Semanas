# semanas

Ajuda a organizar sua semana

## TODOS

[] Cards da página inicial
[] tela que mostra a nota
[] organizar a build
[] migrar para android X